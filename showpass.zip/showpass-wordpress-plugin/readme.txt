Welcome to the Showpass Wordpress Plugin.

List events, display event details and products. Use the Showpass purchase widget for on site ticket & product purchases all with easy to use shortcodes.

See our git repo here for full documentation. https://github.com/showpass/showpass-wordpress-plugin

Visit https://www.showpass.com/organizations/register/ to register your organization and start selling tickets to your next event

For support please email support@showpass.com or visit https://www.showpass.com and use our support chat feature in the bottom right hand corner of your browser window.

Here's to your next successful event!

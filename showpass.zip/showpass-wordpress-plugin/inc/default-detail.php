<div id="page" class="showpass-flex-box">
	<?php
	 $event_data = json_decode($data, true);
  	if (isset($event_data['detail'])) { ?>
  		<div class="showpass-layout-flex">
  			<h2>Sorry, we cannot find the event that you are looking for!</h2>
  		</div>
  	<?php } else {
		$event = $event_data;
		$current_event = $event['id'];?>
		<div class="showpass-layout-flex showpass-detail-event-name">
			<div class="flex-100 showpass-flex-column showpass-no-border">
				<img class="showpass-detail-image" alt="<?php echo $event['name']; ?>" src="<?php echo $event['image_banner']; ?>" />
			</div>
		</div>
		<div class="showpass-layout-flex showpass-detail-event-name">
			<div class="flex-100 showpass-flex-column showpass-no-border"><h1 class="w100"><?php echo $event['name']; ?></h1></div>
		</div>
		<div class="flex-container showpass-layout-flex">
			<div class="flex-66 showpass-flex-column showpass-no-border">
				<div class="w100">
          <?php if (!$event['has_related_events']) { ?>
  					<?php if(showpass_ticket_sold_out($event['ticket_types'])) { ?>
  						<span class="showpass-detail-buy showpass-hide-medium showpass-soldout">
  							SOLD OUT
  						</span>
  					<?php } else { ?>
    					<span class="showpass-detail-buy showpass-hide-medium open-ticket-widget" id="<?php echo $event['slug']; ?>">
    						<?php if ($event['initiate_purchase_button'] == 'ipbd_buy_tickets') { ?>
    							BUY TICKETS
    						<?php } else if ($event['initiate_purchase_button'] == 'ipbd_register') { ?>
    							REGISTER
    						<?php } ?>
    					</span>
  			    <?php } ?>
          <?php } else { ?>
            <select class="showpass-date-select showpass-hide-medium">
              <option value=""> - SELECT DATE - </option>
              <option value="<?php echo $event['slug'];?>">
                <?php echo showpass_get_event_date($event['starts_on'], $event['timezone'], false);?> <?php echo showpass_get_event_time($event['starts_on'], $event['timezone'], false);?> <?php echo showpass_get_timezone_abbr($event['timezone'], false);?>
              </option>
              <?php foreach ($event['related_events'] as $related) { ?>
                <option value="<?php echo $related['slug'];?>">
                  <?php echo showpass_get_event_date($related['starts_on'], $related['timezone'], false);?> <?php echo showpass_get_event_time($related['starts_on'], $related['timezone'], false);?> <?php echo showpass_get_timezone_abbr($related['timezone'], false);?>
                </option>
              <?php } ?>
            </select>
          <?php } ?>
					<?php echo $event['description'];?>
				</div>
			</div>
			<div class="flex-33 showpass-flex-column showpass-no-border">
				<div class="w100">
					<div class="showpass-detail-event-date mb30">
            <?php
            $location = $event['location'];
            if (!$event['has_related_events']) { ?>
  						<div class="info"><i class="fa fa-calendar icon-center"></i><?php echo showpass_get_event_date($event['starts_on'], $event['timezone'], false);?></div>
  						<div class="info"><i class="fa fa-clock-o icon-center"></i><?php echo showpass_get_event_time($event['starts_on'], $event['timezone'], false);?> - <?php echo showpass_get_event_time($event['ends_on'], $event['timezone'], false);?>
  							<?php echo showpass_get_timezone_abbr($event['timezone'], false);?></div>
  						<div class="info"><i class="fa fa-map-marker icon-center"></i><?php echo $location['name'];?></div>
  						<?php if ($event['ticket_types']) : ?>
                <div class="info mb20"><i class="fa fa-tags icon-center"></i><?php echo showpass_get_price_range($event['ticket_types']);?>
                  <?php if (showpass_get_price_range($event['ticket_types']) != 'FREE') { echo $event['currency']; } ?></div>
              <?php endif; ?>
							<?php if(showpass_ticket_sold_out($event['ticket_types'])) {?>
								<span class="showpass-detail-buy showpass-soldout">
									SOLD OUT
								</span>
							<?php } else { ?>
								<span class="showpass-detail-buy open-ticket-widget" id="<?php echo $event['slug']; ?>">
	                <?php if ($event['initiate_purchase_button'] == 'ipbd_buy_tickets') { ?>
	                  BUY TICKETS
	                <?php } else if ($event['initiate_purchase_button'] == 'ipbd_register') { ?>
	                  REGISTER
	                <?php } ?>
	            	</span>
							<?php } ?>
            <?php } else { ?>
              <select class="showpass-date-select">
                <option value=""> - SELECT DATE - </option>
                <option value="<?php echo $event['slug'];?>">
                  <?php echo showpass_get_event_date($event['starts_on'], $event['timezone'], false);?> <?php echo showpass_get_event_time($event['starts_on'], $event['timezone'], false);?> <?php echo showpass_get_timezone_abbr($event['timezone'], false);?>
                </option>
                <?php foreach ($event['related_events'] as $related) { ?>
                  <option value="<?php echo $related['slug'];?>">
                    <?php echo showpass_get_event_date($related['starts_on'], $related['timezone'], false);?> <?php echo showpass_get_event_time($related['starts_on'], $related['timezone'], false);?> <?php echo showpass_get_timezone_abbr($related['timezone'], false);?>
                  </option>
                <?php } ?>
              </select>
            <?php } ?>
					</div>
					<div class="text-center showpass-detail-location">
						<h3 class="showpass-event-veune-name"><?php echo $location['name'];?></h3>
						<span class="showpass-detail-address"><?php echo rtrim($location['street_name']);?>, <?php echo $location['city'];?></span>
						<iframe width="100%" height="300" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDe9oSMuAfjkjtblej94RJvQh3ioWJb4go&q=<?php echo urlencode($location['name']);?>,<?php echo urlencode($location['city']);?>+<?php echo urlencode($location['province']);?>
							&center=<?php echo $location['position'];?>" allowfullscreen>
						</iframe>
						<?php //echo do_shortcode('[codepeople-post-map name="'.$event->location->name.'" center="'.$event->location->position.'" width="100% height="300"]'); ?>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
</div>
